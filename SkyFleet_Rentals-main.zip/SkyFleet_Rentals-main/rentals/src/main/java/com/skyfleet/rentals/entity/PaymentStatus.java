package com.skyfleet.rentals.entity;

public enum PaymentStatus {
	 PENDING,
     COMPLETED,
     FAILED
}
