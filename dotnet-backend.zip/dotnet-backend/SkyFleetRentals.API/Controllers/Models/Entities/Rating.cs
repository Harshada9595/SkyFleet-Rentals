using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SkyFleetRentals.API.Models.Entities
{
    public class Rating : BaseEntity
    {
        [Required]
        public int DroneId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required]
        [Range(1, 5)]
        public int Score { get; set; }

        [StringLength(1000)]
        public string? Comment { get; set; }

        // Navigation properties
        [ForeignKey("DroneId")]
        public virtual Drone Drone { get; set; } = null!;

        [ForeignKey("UserId")]
        public virtual User User { get; set; } = null!;
    }
}
