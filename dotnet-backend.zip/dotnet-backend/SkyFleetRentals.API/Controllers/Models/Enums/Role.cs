namespace SkyFleetRentals.API.Models.Enums
{
    public enum Role
    {
        USER,
        ADMIN
    }
}
