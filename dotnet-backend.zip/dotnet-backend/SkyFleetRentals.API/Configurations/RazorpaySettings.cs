namespace SkyFleetRentals.API.Configurations
{
    public class RazorpaySettings
    {
        public string KeyId { get; set; } = string.Empty;
        public string KeySecret { get; set; } = string.Empty;
    }
}
