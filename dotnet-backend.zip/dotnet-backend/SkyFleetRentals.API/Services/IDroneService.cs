using SkyFleetRentals.API.Models.DTOs;

namespace SkyFleetRentals.API.Services
{
    public interface IDroneService
    {
        Task<List<DroneDto>> GetAllDronesAsync();
        Task<DroneDto?> GetDroneByIdAsync(int id);
        Task<List<DroneDto>> GetAvailableDronesAsync();
        Task<DroneDto> CreateDroneAsync(CreateDroneRequest request);
        Task<DroneDto?> UpdateDroneAsync(int id, UpdateDroneRequest request);
        Task<bool> DeleteDroneAsync(int id);
        Task<bool> IsDroneAvailableAsync(int droneId, DateTime startTime, DateTime endTime);
    }
}
