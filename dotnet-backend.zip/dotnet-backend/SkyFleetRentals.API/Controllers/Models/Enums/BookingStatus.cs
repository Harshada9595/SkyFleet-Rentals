namespace SkyFleetRentals.API.Models.Enums
{
    public enum BookingStatus
    {
        PENDING,
        CONFIRMED,
        DELIVERED,
        RETURNED,
        CANCELLED
    }
}
