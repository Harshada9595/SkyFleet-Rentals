using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkyFleetRentals.API.Models.DTOs;
using SkyFleetRentals.API.Services;

namespace SkyFleetRentals.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentService _paymentService;

        public PaymentController(IPaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        [HttpPost("order")]
        public async Task<ActionResult<PaymentResponse>> CreateOrder([FromBody] CreateOrderRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await _paymentService.CreateOrderAsync(request);
            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }

        [HttpPost("verify")]
        public async Task<ActionResult<PaymentResponse>> VerifyPayment([FromBody] VerifyPaymentRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var response = await _paymentService.VerifyPaymentAsync(request);
            if (!response.Success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }

        [HttpGet("status/{orderId}")]
        public async Task<ActionResult<PaymentResponse>> GetPaymentStatus(string orderId)
        {
            var response = await _paymentService.GetPaymentStatusAsync(orderId);
            if (!response.Success)
            {
                return NotFound(response);
            }

            return Ok(response);
        }
    }
}
