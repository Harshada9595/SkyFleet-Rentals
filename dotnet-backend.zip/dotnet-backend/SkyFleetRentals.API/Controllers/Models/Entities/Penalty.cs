using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Models.Entities
{
    public class Penalty : BaseEntity
    {
        [Required]
        public int BookingId { get; set; }

        [Required]
        public PenaltyReasonStatus PenaltyReason { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal PenaltyAmount { get; set; }

        [Required]
        public PenaltyStatus Status { get; set; } = PenaltyStatus.PENDING;

        [StringLength(500)]
        public string? Description { get; set; }

        public DateTime? PaidDateTime { get; set; }

        // Navigation property
        [ForeignKey("BookingId")]
        public virtual Booking Booking { get; set; } = null!;
    }
}
