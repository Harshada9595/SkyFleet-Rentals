using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkyFleetRentals.API.Models.DTOs;
using SkyFleetRentals.API.Services;

namespace SkyFleetRentals.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DroneController : ControllerBase
    {
        private readonly IDroneService _droneService;

        public DroneController(IDroneService droneService)
        {
            _droneService = droneService;
        }

        [HttpGet]
        public async Task<ActionResult<List<DroneDto>>> GetAllDrones()
        {
            var drones = await _droneService.GetAllDronesAsync();
            return Ok(drones);
        }

        [HttpGet("available")]
        public async Task<ActionResult<List<DroneDto>>> GetAvailableDrones()
        {
            var drones = await _droneService.GetAvailableDronesAsync();
            return Ok(drones);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<DroneDto>> GetDroneById(int id)
        {
            var drone = await _droneService.GetDroneByIdAsync(id);
            if (drone == null)
            {
                return NotFound(new { message = "Drone not found" });
            }

            return Ok(drone);
        }

        [HttpPost]
        [Authorize(Roles = "ADMIN")]
        public async Task<ActionResult<DroneDto>> CreateDrone([FromBody] CreateDroneRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var drone = await _droneService.CreateDroneAsync(request);
            return CreatedAtAction(nameof(GetDroneById), new { id = drone.Id }, drone);
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "ADMIN")]
        public async Task<ActionResult<DroneDto>> UpdateDrone(int id, [FromBody] UpdateDroneRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var drone = await _droneService.UpdateDroneAsync(id, request);
            if (drone == null)
            {
                return NotFound(new { message = "Drone not found" });
            }

            return Ok(drone);
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "ADMIN")]
        public async Task<ActionResult> DeleteDrone(int id)
        {
            var success = await _droneService.DeleteDroneAsync(id);
            if (!success)
            {
                return NotFound(new { message = "Drone not found" });
            }

            return NoContent();
        }

        [HttpGet("{id}/availability")]
        public async Task<ActionResult> CheckAvailability(int id, [FromQuery] DateTime startTime, [FromQuery] DateTime endTime)
        {
            var isAvailable = await _droneService.IsDroneAvailableAsync(id, startTime, endTime);
            return Ok(new { isAvailable });
        }
    }
}
