package com.skyfleet.rentals.entity;

public enum PenaltyStatus {
	 PENDING,
     APPLIED,
     WAIVED,
     PAID
}
