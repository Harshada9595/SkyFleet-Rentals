package com.skyfleet.rentals.entity;

public enum RatingValue {
    ONE,
    TWO,
    THREE,
    FOUR,
    FIVE
}
