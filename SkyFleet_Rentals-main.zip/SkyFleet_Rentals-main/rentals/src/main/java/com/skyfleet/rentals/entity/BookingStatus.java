package com.skyfleet.rentals.entity;

public enum BookingStatus {
	 PENDING,
     CONFIRMED,
     COMPLETED,
     CANCELLED
}
