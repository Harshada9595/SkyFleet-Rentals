using Microsoft.EntityFrameworkCore;
using SkyFleetRentals.API.Models.Entities;

namespace SkyFleetRentals.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Drone> Drones { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Penalty> Penalties { get; set; }
        public DbSet<Undertaking> Undertakings { get; set; }
        public DbSet<Rating> Ratings { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User configuration
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(e => e.Email).IsUnique();
                entity.Property(e => e.Email).IsRequired();
                entity.Property(e => e.Password).IsRequired();
            });

            // Drone configuration
            modelBuilder.Entity<Drone>(entity =>
            {
                entity.Property(e => e.PricePerHour).HasColumnType("decimal(18,2)");
                entity.Property(e => e.DronePrice).HasColumnType("decimal(18,2)");
            });

            // Booking configuration
            modelBuilder.Entity<Booking>(entity =>
            {
                entity.Property(e => e.TotalAmount).HasColumnType("decimal(18,2)");
                entity.HasOne(e => e.User).WithMany(e => e.Bookings).HasForeignKey(e => e.UserId);
                entity.HasOne(e => e.Drone).WithMany(e => e.Bookings).HasForeignKey(e => e.DroneId);
            });

            // Payment configuration
            modelBuilder.Entity<Payment>(entity =>
            {
                entity.Property(e => e.Amount).HasColumnType("decimal(18,2)");
                entity.HasOne(e => e.Booking).WithMany(e => e.Payments).HasForeignKey(e => e.BookingId);
            });

            // Penalty configuration
            modelBuilder.Entity<Penalty>(entity =>
            {
                entity.Property(e => e.PenaltyAmount).HasColumnType("decimal(18,2)");
                entity.HasOne(e => e.Booking).WithMany(e => e.Penalties).HasForeignKey(e => e.BookingId);
            });

            // Undertaking configuration
            modelBuilder.Entity<Undertaking>(entity =>
            {
                entity.HasOne(e => e.Booking).WithMany(e => e.Undertakings).HasForeignKey(e => e.BookingId);
            });

            // Rating configuration
            modelBuilder.Entity<Rating>(entity =>
            {
                entity.HasOne(e => e.Drone).WithMany(e => e.Ratings).HasForeignKey(e => e.DroneId);
                entity.HasOne(e => e.User).WithMany(e => e.Ratings).HasForeignKey(e => e.UserId);
            });
        }
    }
}
