package com.skyfleet.rentals.entity;

public enum PenaltyReasonStatus {
	LATE_RETURN,
	DAMAGE,
	CANCELLATION

}
