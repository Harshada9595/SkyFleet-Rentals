using System.ComponentModel.DataAnnotations;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Models.DTOs
{
    public class DroneDto
    {
        public int Id { get; set; }
        public string Model { get; set; } = string.Empty;
        public string Brand { get; set; } = string.Empty;
        public DroneStatus Status { get; set; }
        public decimal PricePerHour { get; set; }
        public int BatteryLife { get; set; }
        public string Location { get; set; } = string.Empty;
        public string ImageUrl { get; set; } = string.Empty;
        public string GuideUrl { get; set; } = string.Empty;
        public decimal DronePrice { get; set; }
        public double AverageRating { get; set; }
        public int TotalRatings { get; set; }
    }

    public class CreateDroneRequest
    {
        [Required]
        [StringLength(100)]
        public string Model { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Brand { get; set; } = string.Empty;

        [Required]
        [Range(0, double.MaxValue)]
        public decimal PricePerHour { get; set; }

        [Required]
        [Range(1, 100)]
        public int BatteryLife { get; set; }

        [Required]
        [StringLength(255)]
        public string Location { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string ImageUrl { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string GuideUrl { get; set; } = string.Empty;

        [Required]
        [Range(0, double.MaxValue)]
        public decimal DronePrice { get; set; }
    }

    public class UpdateDroneRequest
    {
        [StringLength(100)]
        public string? Model { get; set; }

        [StringLength(100)]
        public string? Brand { get; set; }

        public DroneStatus? Status { get; set; }

        [Range(0, double.MaxValue)]
        public decimal? PricePerHour { get; set; }

        [Range(1, 100)]
        public int? BatteryLife { get; set; }

        [StringLength(255)]
        public string? Location { get; set; }

        [StringLength(500)]
        public string? ImageUrl { get; set; }

        [StringLength(500)]
        public string? GuideUrl { get; set; }

        [Range(0, double.MaxValue)]
        public decimal? DronePrice { get; set; }
    }
}
