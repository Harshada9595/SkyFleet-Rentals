using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SkyFleetRentals.API.Models.DTOs;
using SkyFleetRentals.API.Services;

namespace SkyFleetRentals.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class BookingController : ControllerBase
    {
        private readonly IBookingService _bookingService;

        public BookingController(IBookingService bookingService)
        {
            _bookingService = bookingService;
        }

        [HttpGet]
        [Authorize(Roles = "ADMIN")]
        public async Task<ActionResult<List<BookingDto>>> GetAllBookings()
        {
            var bookings = await _bookingService.GetAllBookingsAsync();
            return Ok(bookings);
        }

        [HttpGet("my-bookings")]
        public async Task<ActionResult<List<BookingDto>>> GetMyBookings()
        {
            var userId = GetUserIdFromToken();
            if (userId == null)
            {
                return Unauthorized();
            }

            var bookings = await _bookingService.GetUserBookingsAsync(userId.Value);
            return Ok(bookings);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BookingDto>> GetBookingById(int id)
        {
            var booking = await _bookingService.GetBookingByIdAsync(id);
            if (booking == null)
            {
                return NotFound(new { message = "Booking not found" });
            }

            // Check if user is authorized to view this booking
            var userId = GetUserIdFromToken();
            if (userId == null || (booking.UserId != userId.Value && !User.IsInRole("ADMIN")))
            {
                return Forbid();
            }

            return Ok(booking);
        }

        [HttpPost]
        public async Task<ActionResult<BookingDto>> CreateBooking([FromBody] CreateBookingRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var userId = GetUserIdFromToken();
            if (userId == null)
            {
                return Unauthorized();
            }

            try
            {
                var booking = await _bookingService.CreateBookingAsync(userId.Value, request);
                return CreatedAtAction(nameof(GetBookingById), new { id = booking.Id }, booking);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        [Authorize(Roles = "ADMIN")]
        public async Task<ActionResult<BookingDto>> UpdateBooking(int id, [FromBody] UpdateBookingRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var booking = await _bookingService.UpdateBookingAsync(id, request);
            if (booking == null)
            {
                return NotFound(new { message = "Booking not found" });
            }

            return Ok(booking);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> CancelBooking(int id)
        {
            var booking = await _bookingService.GetBookingByIdAsync(id);
            if (booking == null)
            {
                return NotFound(new { message = "Booking not found" });
            }

            // Check if user is authorized to cancel this booking
            var userId = GetUserIdFromToken();
            if (userId == null || (booking.UserId != userId.Value && !User.IsInRole("ADMIN")))
            {
                return Forbid();
            }

            var success = await _bookingService.CancelBookingAsync(id);
            if (!success)
            {
                return NotFound(new { message = "Booking not found" });
            }

            return NoContent();
        }

        [HttpPatch("{id}/return")]
        [Authorize(Roles = "ADMIN")]
        public async Task<ActionResult> ReturnBooking(int id, [FromBody] ReturnBookingRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var success = await _bookingService.ReturnBookingAsync(id, request);
            if (!success)
            {
                return NotFound(new { message = "Booking not found" });
            }

            return Ok(new { message = "Booking returned successfully" });
        }

        [HttpGet("calculate-amount")]
        public async Task<ActionResult> CalculateAmount([FromQuery] int droneId, [FromQuery] DateTime startTime, [FromQuery] DateTime endTime)
        {
            var amount = await _bookingService.CalculateTotalAmountAsync(droneId, startTime, endTime);
            return Ok(new { amount });
        }

        private int? GetUserIdFromToken()
        {
            var userIdClaim = User.FindFirst("sub")?.Value;
            if (int.TryParse(userIdClaim, out var userId))
            {
                return userId;
            }
            return null;
        }
    }
}
