package com.skyfleet.rentals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalsApplicationTests {

	@Test
	void contextLoads() {
	}

}
