namespace SkyFleetRentals.API.Models.Enums
{
    public enum PaymentStatus
    {
        PENDING,
        COMPLETED,
        FAILED,
        REFUNDED
    }
}
