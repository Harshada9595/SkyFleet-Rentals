using System.ComponentModel.DataAnnotations;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Models.DTOs
{
    public class BookingDto
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string UserName { get; set; } = string.Empty;
        public int DroneId { get; set; }
        public string DroneModel { get; set; } = string.Empty;
        public string DroneBrand { get; set; } = string.Empty;
        public DateTime BookingDateTime { get; set; }
        public DateTime? DeliveryDateTime { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public decimal TotalAmount { get; set; }
        public BookingStatus Status { get; set; }
        public DeliveryStatus DeliveryStatus { get; set; }
        public List<PaymentDto> Payments { get; set; } = new List<PaymentDto>();
        public List<PenaltyDto> Penalties { get; set; } = new List<PenaltyDto>();
        public List<UndertakingDto> Undertakings { get; set; } = new List<UndertakingDto>();
    }

    public class CreateBookingRequest
    {
        [Required]
        public int DroneId { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }
    }

    public class UpdateBookingRequest
    {
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public BookingStatus? Status { get; set; }
        public DeliveryStatus? DeliveryStatus { get; set; }
    }

    public class ReturnBookingRequest
    {
        [Required]
        public bool IsDamaged { get; set; }

        [StringLength(500)]
        public string? DamageDescription { get; set; }
    }
}

public class PaymentDto
{
    public int Id { get; set; }
    public string RazorpayOrderId { get; set; } = string.Empty;
    public string? RazorpayPaymentId { get; set; }
    public decimal Amount { get; set; }
    public PaymentStatus Status { get; set; }
    public string? Description { get; set; }
    public DateTime? PaymentDateTime { get; set; }
}

public class PenaltyDto
{
    public int Id { get; set; }
    public PenaltyReasonStatus PenaltyReason { get; set; }
    public decimal PenaltyAmount { get; set; }
    public PenaltyStatus Status { get; set; }
    public string? Description { get; set; }
    public DateTime? PaidDateTime { get; set; }
}

public class UndertakingDto
{
    public int Id { get; set; }
    public bool IsAccepted { get; set; }
    public string Terms { get; set; } = string.Empty;
    public DateTime? AcceptedDateTime { get; set; }
}
