using Microsoft.EntityFrameworkCore;
using SkyFleetRentals.API.Models.Entities;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Data
{
    public static class DbInitializer
    {
        public static void Initialize(ApplicationDbContext context)
        {
            context.Database.EnsureCreated();

            // Check if data already exists
            if (context.Users.Any())
            {
                return;
            }

            // Seed Users
            var adminUser = new User
            {
                Name = "Admin User",
                Email = "admin@skyfleet.com",
                Password = BCrypt.Net.BCrypt.HashPassword("admin123"),
                Phone = "1234567890",
                Address = "123 Admin Street, City",
                Role = Role.ADMIN
            };

            var regularUser = new User
            {
                Name = "John Doe",
                Email = "john@example.com",
                Password = BCrypt.Net.BCrypt.HashPassword("user123"),
                Phone = "9876543210",
                Address = "456 User Avenue, Town",
                Role = Role.USER
            };

            context.Users.AddRange(adminUser, regularUser);
            context.SaveChanges();

            // Seed Drones
            var drones = new List<Drone>
            {
                new Drone
                {
                    Model = "DJI Mavic Air 2",
                    Brand = "DJI",
                    Status = DroneStatus.AVAILABLE,
                    PricePerHour = 50.00m,
                    BatteryLife = 34,
                    Location = "Mumbai",
                    ImageUrl = "https://example.com/images/dji-mavic-air-2.jpg",
                    GuideUrl = "https://example.com/guides/dji-mavic-air-2.pdf",
                    DronePrice = 1200.00m
                },
                new Drone
                {
                    Model = "Parrot Anafi",
                    Brand = "Parrot",
                    Status = DroneStatus.AVAILABLE,
                    PricePerHour = 45.00m,
                    BatteryLife = 25,
                    Location = "Delhi",
                    ImageUrl = "https://example.com/images/parrot-anafi.jpg",
                    GuideUrl = "https://example.com/guides/parrot-anafi.pdf",
                    DronePrice = 900.00m
                },
                new Drone
                {
                    Model = "Autel EVO II",
                    Brand = "Autel",
                    Status = DroneStatus.AVAILABLE,
                    PricePerHour = 60.00m,
                    BatteryLife = 40,
                    Location = "Bangalore",
                    ImageUrl = "https://example.com/images/autel-evo-ii.jpg",
                    GuideUrl = "https://example.com/guides/autel-evo-ii.pdf",
                    DronePrice = 1500.00m
                },
                new Drone
                {
                    Model = "Skydio 2",
                    Brand = "Skydio",
                    Status = DroneStatus.MAINTENANCE,
                    PricePerHour = 55.00m,
                    BatteryLife = 23,
                    Location = "Chennai",
                    ImageUrl = "https://example.com/images/skydio-2.jpg",
                    GuideUrl = "https://example.com/guides/skydio-2.pdf",
                    DronePrice = 1100.00m
                },
                new Drone
                {
                    Model = "Yuneec Typhoon H",
                    Brand = "Yuneec",
                    Status = DroneStatus.AVAILABLE,
                    PricePerHour = 70.00m,
                    BatteryLife = 25,
                    Location = "Hyderabad",
                    ImageUrl = "https://example.com/images/yuneec-typhoon-h.jpg",
                    GuideUrl = "https://example.com/guides/yuneec-typhoon-h.pdf",
                    DronePrice = 1800.00m
                }
            };

            context.Drones.AddRange(drones);
            context.SaveChanges();

            // Seed Sample Bookings
            var sampleBooking = new Booking
            {
                UserId = regularUser.Id,
                DroneId = drones[0].Id,
                StartTime = DateTime.UtcNow.AddDays(1),
                EndTime = DateTime.UtcNow.AddDays(1).AddHours(3),
                TotalAmount = 150.00m,
                Status = BookingStatus.PENDING,
                DeliveryStatus = DeliveryStatus.PENDING
            };

            context.Bookings.Add(sampleBooking);
            context.SaveChanges();

            // Seed Sample Undertaking
            var undertaking = new Undertaking
            {
                BookingId = sampleBooking.Id,
                IsAccepted = true,
                Terms = "I agree to use the drone responsibly and return it in the same condition. I understand that I am liable for any damage or loss during the rental period.",
                AcceptedDateTime = DateTime.UtcNow
            };

            context.Undertakings.Add(undertaking);
            context.SaveChanges();

            // Seed Sample Ratings
            var ratings = new List<Rating>
            {
                new Rating
                {
                    DroneId = drones[0].Id,
                    UserId = regularUser.Id,
                    Score = 5,
                    Comment = "Excellent drone, very easy to fly and great camera quality!"
                },
                new Rating
                {
                    DroneId = drones[1].Id,
                    UserId = regularUser.Id,
                    Score = 4,
                    Comment = "Good drone, but battery life could be better."
                }
            };

            context.Ratings.AddRange(ratings);
            context.SaveChanges();
        }
    }
}
