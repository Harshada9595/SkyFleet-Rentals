using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Models.Entities
{
    public class Payment : BaseEntity
    {
        [Required]
        public int BookingId { get; set; }

        [Required]
        [StringLength(100)]
        public string RazorpayOrderId { get; set; } = string.Empty;

        [StringLength(100)]
        public string? RazorpayPaymentId { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        [Required]
        public PaymentStatus Status { get; set; } = PaymentStatus.PENDING;

        [StringLength(500)]
        public string? Description { get; set; }

        public DateTime? PaymentDateTime { get; set; }

        // Navigation property
        [ForeignKey("BookingId")]
        public virtual Booking Booking { get; set; } = null!;
    }
}
