namespace SkyFleetRentals.API.Models.Enums
{
    public enum DeliveryStatus
    {
        PENDING,
        DELIVERED,
        RETURNED
    }
}
