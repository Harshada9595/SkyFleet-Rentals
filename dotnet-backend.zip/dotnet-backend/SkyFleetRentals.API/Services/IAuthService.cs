using SkyFleetRentals.API.Models.DTOs;

namespace SkyFleetRentals.API.Services
{
    public interface IAuthService
    {
        Task<AuthResponse?> LoginAsync(LoginRequest request);
        Task<AuthResponse?> RegisterAsync(RegisterRequest request);
        Task<bool> ChangePasswordAsync(int userId, string currentPassword, string newPassword);
    }
}
