using SkyFleetRentals.API.Models.DTOs;

namespace SkyFleetRentals.API.Services
{
    public interface IPaymentService
    {
        Task<PaymentResponse> CreateOrderAsync(CreateOrderRequest request);
        Task<PaymentResponse> VerifyPaymentAsync(VerifyPaymentRequest request);
        Task<PaymentResponse> GetPaymentStatusAsync(string orderId);
    }
}
