using SkyFleetRentals.API.Models.DTOs;

namespace SkyFleetRentals.API.Services
{
    public interface IBookingService
    {
        Task<List<BookingDto>> GetAllBookingsAsync();
        Task<BookingDto?> GetBookingByIdAsync(int id);
        Task<List<BookingDto>> GetUserBookingsAsync(int userId);
        Task<BookingDto> CreateBookingAsync(int userId, CreateBookingRequest request);
        Task<BookingDto?> UpdateBookingAsync(int id, UpdateBookingRequest request);
        Task<bool> CancelBookingAsync(int id);
        Task<bool> ReturnBookingAsync(int id, ReturnBookingRequest request);
        Task<decimal> CalculateTotalAmountAsync(int droneId, DateTime startTime, DateTime endTime);
    }
}
