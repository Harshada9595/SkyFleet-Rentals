namespace SkyFleetRentals.API.Models.Enums
{
    public enum DroneStatus
    {
        AVAILABLE,
        RENTED,
        MAINTENANCE,
        RETIRED
    }
}
