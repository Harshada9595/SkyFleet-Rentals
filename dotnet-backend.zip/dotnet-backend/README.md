# SkyFleet Rentals - .NET Core Backend

A comprehensive .NET Core 8.0 backend API for the SkyFleet Rentals drone rental platform.

## Features

- **Authentication & Authorization**: JWT-based authentication with role-based access control
- **Drone Management**: CRUD operations for drone inventory
- **Booking System**: Complete booking lifecycle management
- **Payment Integration**: Razorpay payment gateway integration
- **Penalty System**: Automated penalty calculation and management
- **Rating System**: User reviews and ratings for drones
- **Undertaking Management**: User agreement handling

## Tech Stack

- **Framework**: .NET Core 8.0
- **ORM**: Entity Framework Core
- **Database**: SQL Server (LocalDB for development)
- **Authentication**: JWT Bearer Tokens
- **Payment**: Razorpay Integration
- **Documentation**: Swagger/OpenAPI
- **Password Hashing**: BCrypt

## Project Structure

```
SkyFleetRentals.API/
├── Controllers/          # API Controllers
├── Data/                # Database Context
├── Models/
│   ├── Entities/        # Database Entities
│   ├── Enums/          # Enum Definitions
│   └── DTOs/           # Data Transfer Objects
├── Services/            # Business Logic Services
├── Configurations/      # Configuration Classes
└── Middleware/          # Custom Middleware
```

## Setup Instructions

### Prerequisites

- .NET 8.0 SDK
- SQL Server LocalDB (or SQL Server)
- Visual Studio 2022 or VS Code

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd dotnet-backend/SkyFleetRentals.API
   ```

2. **Install dependencies**
   ```bash
   dotnet restore
   ```

3. **Configure database connection**
   - Update `appsettings.json` with your database connection string
   - For LocalDB (default): No changes needed
   - For SQL Server: Update the connection string

4. **Configure Razorpay (Optional)**
   - Get your Razorpay API keys from the Razorpay dashboard
   - Update `appsettings.json` with your keys:
   ```json
   "RazorpaySettings": {
     "KeyId": "your_razorpay_key_id",
     "KeySecret": "your_razorpay_key_secret"
   }
   ```

5. **Run the application**
   ```bash
   dotnet run
   ```

6. **Access the API**
   - API Base URL: `https://localhost:7000/api`
   - Swagger Documentation: `https://localhost:7000/swagger`

## API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/change-password` - Change password

### Drones
- `GET /api/drone` - Get all drones
- `GET /api/drone/available` - Get available drones
- `GET /api/drone/{id}` - Get drone by ID
- `POST /api/drone` - Create drone (Admin only)
- `PUT /api/drone/{id}` - Update drone (Admin only)
- `DELETE /api/drone/{id}` - Delete drone (Admin only)
- `GET /api/drone/{id}/availability` - Check drone availability

### Bookings
- `GET /api/booking` - Get all bookings (Admin only)
- `GET /api/booking/my-bookings` - Get user's bookings
- `GET /api/booking/{id}` - Get booking by ID
- `POST /api/booking` - Create booking
- `PUT /api/booking/{id}` - Update booking (Admin only)
- `DELETE /api/booking/{id}` - Cancel booking
- `PATCH /api/booking/{id}/return` - Return booking (Admin only)
- `GET /api/booking/calculate-amount` - Calculate booking amount

### Payments
- `POST /api/payment/order` - Create Razorpay order
- `POST /api/payment/verify` - Verify payment
- `GET /api/payment/status/{orderId}` - Get payment status

## Database Schema

### Core Entities

1. **User** - User accounts with roles (USER, ADMIN)
2. **Drone** - Drone inventory with availability status
3. **Booking** - Rental bookings with status tracking
4. **Payment** - Payment records with Razorpay integration
5. **Penalty** - Penalty records for late returns/damage
6. **Undertaking** - User agreements and terms
7. **Rating** - User reviews and ratings

### Relationships

- User → Bookings (One-to-Many)
- Drone → Bookings (One-to-Many)
- Booking → Payments (One-to-Many)
- Booking → Penalties (One-to-Many)
- Booking → Undertakings (One-to-Many)
- Drone → Ratings (One-to-Many)
- User → Ratings (One-to-Many)

## Authentication

The API uses JWT Bearer tokens for authentication. Include the token in the Authorization header:

```
Authorization: Bearer <your-jwt-token>
```

### User Roles

- **USER**: Can book drones, view their bookings, make payments
- **ADMIN**: Full access to all endpoints, can manage drones and bookings

## Payment Integration

The backend integrates with Razorpay for payment processing:

1. **Create Order**: Generate Razorpay order for booking payment
2. **Payment Verification**: Verify payment signature and update booking status
3. **Status Tracking**: Track payment status throughout the process

## Development

### Adding New Features

1. Create entity in `Models/Entities/`
2. Add DbSet to `ApplicationDbContext`
3. Create DTOs in `Models/DTOs/`
4. Implement service in `Services/`
5. Create controller in `Controllers/`
6. Update `Program.cs` with new service registration

### Database Migrations

```bash
# Create migration
dotnet ef migrations add MigrationName

# Update database
dotnet ef database update
```

## Environment Variables

For production deployment, set these environment variables:

- `ASPNETCORE_ENVIRONMENT=Production`
- `ConnectionStrings__DefaultConnection` - Database connection string
- `JwtSettings__SecretKey` - JWT secret key
- `RazorpaySettings__KeyId` - Razorpay key ID
- `RazorpaySettings__KeySecret` - Razorpay key secret

## Deployment

### Azure Deployment

1. Create Azure App Service
2. Configure connection string in Application Settings
3. Set environment variables
4. Deploy using Azure DevOps or GitHub Actions

### Docker Deployment

```bash
# Build Docker image
docker build -t skyfleet-rentals-api .

# Run container
docker run -p 8080:80 skyfleet-rentals-api
```

## Testing

The API includes Swagger documentation for testing endpoints. Access it at `/swagger` when running in development mode.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License.
