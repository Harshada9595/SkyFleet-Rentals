namespace SkyFleetRentals.API.Models.Enums
{
    public enum PenaltyStatus
    {
        PENDING,
        PAID,
        WAIVED
    }
}
