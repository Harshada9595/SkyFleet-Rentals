using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Models.Entities
{
    public class Drone : BaseEntity
    {
        [Required]
        [StringLength(100)]
        public string Model { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Brand { get; set; } = string.Empty;

        [Required]
        public DroneStatus Status { get; set; } = DroneStatus.AVAILABLE;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal PricePerHour { get; set; }

        [Required]
        public int BatteryLife { get; set; }

        [Required]
        [StringLength(255)]
        public string Location { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string ImageUrl { get; set; } = string.Empty;

        [Required]
        [StringLength(500)]
        public string GuideUrl { get; set; } = string.Empty;

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal DronePrice { get; set; }

        // Navigation properties
        public virtual ICollection<Booking> Bookings { get; set; } = new List<Booking>();
        public virtual ICollection<Rating> Ratings { get; set; } = new List<Rating>();
    }
}
