using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using SkyFleetRentals.API.Configurations;
using SkyFleetRentals.API.Data;
using SkyFleetRentals.API.Models.DTOs;
using SkyFleetRentals.API.Models.Entities;
using SkyFleetRentals.API.Models.Enums;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace SkyFleetRentals.API.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly ApplicationDbContext _context;
        private readonly RazorpaySettings _razorpaySettings;
        private readonly HttpClient _httpClient;

        public PaymentService(ApplicationDbContext context, IOptions<RazorpaySettings> razorpaySettings, HttpClient httpClient)
        {
            _context = context;
            _razorpaySettings = razorpaySettings.Value;
            _httpClient = httpClient;
        }

        public async Task<PaymentResponse> CreateOrderAsync(CreateOrderRequest request)
        {
            try
            {
                // Verify booking exists
                var booking = await _context.Bookings
                    .Include(b => b.Drone)
                    .FirstOrDefaultAsync(b => b.Id == request.BookingId && !b.IsDeleted);

                if (booking == null)
                {
                    return new PaymentResponse
                    {
                        Success = false,
                        Message = "Booking not found"
                    };
                }

                // Create Razorpay order
                var orderData = new
                {
                    amount = (int)(request.Amount * 100), // Convert to paise
                    currency = "INR",
                    receipt = $"booking_{request.BookingId}_{DateTime.UtcNow.Ticks}",
                    notes = new
                    {
                        booking_id = request.BookingId.ToString(),
                        description = request.Description ?? $"Payment for drone rental - {booking.Drone.Model}"
                    }
                };

                var json = JsonSerializer.Serialize(orderData);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                // Add authentication
                var authToken = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_razorpaySettings.KeyId}:{_razorpaySettings.KeySecret}"));
                _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", authToken);

                var response = await _httpClient.PostAsync("https://api.razorpay.com/v1/orders", content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    return new PaymentResponse
                    {
                        Success = false,
                        Message = $"Failed to create order: {responseContent}"
                    };
                }

                var razorpayResponse = JsonSerializer.Deserialize<RazorpayOrderResponse>(responseContent);

                // Save payment record
                var payment = new Payment
                {
                    BookingId = request.BookingId,
                    RazorpayOrderId = razorpayResponse!.Id,
                    Amount = request.Amount,
                    Status = PaymentStatus.PENDING,
                    Description = request.Description
                };

                _context.Payments.Add(payment);
                await _context.SaveChangesAsync();

                return new PaymentResponse
                {
                    Success = true,
                    Message = "Order created successfully",
                    OrderId = razorpayResponse.Id,
                    Amount = request.Amount
                };
            }
            catch (Exception ex)
            {
                return new PaymentResponse
                {
                    Success = false,
                    Message = $"Error creating order: {ex.Message}"
                };
            }
        }

        public async Task<PaymentResponse> VerifyPaymentAsync(VerifyPaymentRequest request)
        {
            try
            {
                // Verify signature
                var expectedSignature = GenerateSignature(request.RazorpayOrderId, request.RazorpayPaymentId);
                if (expectedSignature != request.RazorpaySignature)
                {
                    return new PaymentResponse
                    {
                        Success = false,
                        Message = "Invalid signature"
                    };
                }

                // Update payment record
                var payment = await _context.Payments
                    .FirstOrDefaultAsync(p => p.RazorpayOrderId == request.RazorpayOrderId);

                if (payment == null)
                {
                    return new PaymentResponse
                    {
                        Success = false,
                        Message = "Payment record not found"
                    };
                }

                payment.RazorpayPaymentId = request.RazorpayPaymentId;
                payment.Status = PaymentStatus.COMPLETED;
                payment.PaymentDateTime = DateTime.UtcNow;

                // Update booking status
                var booking = await _context.Bookings.FindAsync(payment.BookingId);
                if (booking != null)
                {
                    booking.Status = BookingStatus.CONFIRMED;
                    booking.UpdatedAt = DateTime.UtcNow;
                }

                await _context.SaveChangesAsync();

                return new PaymentResponse
                {
                    Success = true,
                    Message = "Payment verified successfully",
                    OrderId = request.RazorpayOrderId,
                    Amount = payment.Amount
                };
            }
            catch (Exception ex)
            {
                return new PaymentResponse
                {
                    Success = false,
                    Message = $"Error verifying payment: {ex.Message}"
                };
            }
        }

        public async Task<PaymentResponse> GetPaymentStatusAsync(string orderId)
        {
            try
            {
                var payment = await _context.Payments
                    .FirstOrDefaultAsync(p => p.RazorpayOrderId == orderId);

                if (payment == null)
                {
                    return new PaymentResponse
                    {
                        Success = false,
                        Message = "Payment not found"
                    };
                }

                return new PaymentResponse
                {
                    Success = true,
                    Message = $"Payment status: {payment.Status}",
                    OrderId = orderId,
                    Amount = payment.Amount
                };
            }
            catch (Exception ex)
            {
                return new PaymentResponse
                {
                    Success = false,
                    Message = $"Error getting payment status: {ex.Message}"
                };
            }
        }

        private string GenerateSignature(string orderId, string paymentId)
        {
            var payload = $"{orderId}|{paymentId}";
            var key = Encoding.UTF8.GetBytes(_razorpaySettings.KeySecret);
            
            using var hmac = new HMACSHA256(key);
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(payload));
            return Convert.ToHexString(hash).ToLower();
        }
    }
}
