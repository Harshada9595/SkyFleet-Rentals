using Microsoft.EntityFrameworkCore;
using SkyFleetRentals.API.Data;
using SkyFleetRentals.API.Models.DTOs;
using SkyFleetRentals.API.Models.Entities;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Services
{
    public class BookingService : IBookingService
    {
        private readonly ApplicationDbContext _context;
        private readonly IDroneService _droneService;

        public BookingService(ApplicationDbContext context, IDroneService droneService)
        {
            _context = context;
            _droneService = droneService;
        }

        public async Task<List<BookingDto>> GetAllBookingsAsync()
        {
            var bookings = await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Drone)
                .Include(b => b.Payments)
                .Include(b => b.Penalties)
                .Include(b => b.Undertakings)
                .Where(b => !b.IsDeleted)
                .OrderByDescending(b => b.BookingDateTime)
                .ToListAsync();

            return bookings.Select(MapToDto).ToList();
        }

        public async Task<BookingDto?> GetBookingByIdAsync(int id)
        {
            var booking = await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Drone)
                .Include(b => b.Payments)
                .Include(b => b.Penalties)
                .Include(b => b.Undertakings)
                .FirstOrDefaultAsync(b => b.Id == id && !b.IsDeleted);

            return booking != null ? MapToDto(booking) : null;
        }

        public async Task<List<BookingDto>> GetUserBookingsAsync(int userId)
        {
            var bookings = await _context.Bookings
                .Include(b => b.User)
                .Include(b => b.Drone)
                .Include(b => b.Payments)
                .Include(b => b.Penalties)
                .Include(b => b.Undertakings)
                .Where(b => b.UserId == userId && !b.IsDeleted)
                .OrderByDescending(b => b.BookingDateTime)
                .ToListAsync();

            return bookings.Select(MapToDto).ToList();
        }

        public async Task<BookingDto> CreateBookingAsync(int userId, CreateBookingRequest request)
        {
            // Check if drone is available
            if (!await _droneService.IsDroneAvailableAsync(request.DroneId, request.StartTime, request.EndTime))
            {
                throw new InvalidOperationException("Drone is not available for the selected time period.");
            }

            var totalAmount = await CalculateTotalAmountAsync(request.DroneId, request.StartTime, request.EndTime);

            var booking = new Booking
            {
                UserId = userId,
                DroneId = request.DroneId,
                StartTime = request.StartTime,
                EndTime = request.EndTime,
                TotalAmount = totalAmount,
                Status = BookingStatus.PENDING,
                DeliveryStatus = DeliveryStatus.PENDING
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            return await GetBookingByIdAsync(booking.Id) ?? throw new InvalidOperationException("Failed to create booking");
        }

        public async Task<BookingDto?> UpdateBookingAsync(int id, UpdateBookingRequest request)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null || booking.IsDeleted) return null;

            if (request.StartTime.HasValue) booking.StartTime = request.StartTime.Value;
            if (request.EndTime.HasValue) booking.EndTime = request.EndTime.Value;
            if (request.Status.HasValue) booking.Status = request.Status.Value;
            if (request.DeliveryStatus.HasValue) booking.DeliveryStatus = request.DeliveryStatus.Value;

            booking.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return await GetBookingByIdAsync(id);
        }

        public async Task<bool> CancelBookingAsync(int id)
        {
            var booking = await _context.Bookings.FindAsync(id);
            if (booking == null || booking.IsDeleted) return false;

            booking.Status = BookingStatus.CANCELLED;
            booking.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> ReturnBookingAsync(int id, ReturnBookingRequest request)
        {
            var booking = await _context.Bookings
                .Include(b => b.Drone)
                .FirstOrDefaultAsync(b => b.Id == id && !b.IsDeleted);

            if (booking == null) return false;

            booking.Status = BookingStatus.RETURNED;
            booking.DeliveryStatus = DeliveryStatus.RETURNED;
            booking.UpdatedAt = DateTime.UtcNow;

            // Update drone status
            booking.Drone.Status = DroneStatus.AVAILABLE;
            booking.Drone.UpdatedAt = DateTime.UtcNow;

            // Create penalty if damaged
            if (request.IsDamaged)
            {
                var penalty = new Penalty
                {
                    BookingId = booking.Id,
                    PenaltyReason = PenaltyReasonStatus.DAMAGE,
                    PenaltyAmount = booking.Drone.DronePrice * 0.1m, // 10% of drone price
                    Status = PenaltyStatus.PENDING,
                    Description = request.DamageDescription ?? "Drone returned with damage"
                };

                _context.Penalties.Add(penalty);
            }

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<decimal> CalculateTotalAmountAsync(int droneId, DateTime startTime, DateTime endTime)
        {
            var drone = await _context.Drones.FindAsync(droneId);
            if (drone == null) return 0;

            var duration = endTime - startTime;
            var hours = (decimal)duration.TotalHours;
            
            return drone.PricePerHour * hours;
        }

        private static BookingDto MapToDto(Booking booking)
        {
            return new BookingDto
            {
                Id = booking.Id,
                UserId = booking.UserId,
                UserName = booking.User.Name,
                DroneId = booking.DroneId,
                DroneModel = booking.Drone.Model,
                DroneBrand = booking.Drone.Brand,
                BookingDateTime = booking.BookingDateTime,
                DeliveryDateTime = booking.DeliveryDateTime,
                StartTime = booking.StartTime,
                EndTime = booking.EndTime,
                TotalAmount = booking.TotalAmount,
                Status = booking.Status,
                DeliveryStatus = booking.DeliveryStatus,
                Payments = booking.Payments.Select(p => new PaymentDto
                {
                    Id = p.Id,
                    RazorpayOrderId = p.RazorpayOrderId,
                    RazorpayPaymentId = p.RazorpayPaymentId,
                    Amount = p.Amount,
                    Status = p.Status,
                    Description = p.Description,
                    PaymentDateTime = p.PaymentDateTime
                }).ToList(),
                Penalties = booking.Penalties.Select(p => new PenaltyDto
                {
                    Id = p.Id,
                    PenaltyReason = p.PenaltyReason,
                    PenaltyAmount = p.PenaltyAmount,
                    Status = p.Status,
                    Description = p.Description,
                    PaidDateTime = p.PaidDateTime
                }).ToList(),
                Undertakings = booking.Undertakings.Select(u => new UndertakingDto
                {
                    Id = u.Id,
                    IsAccepted = u.IsAccepted,
                    Terms = u.Terms,
                    AcceptedDateTime = u.AcceptedDateTime
                }).ToList()
            };
        }
    }
}
