using Microsoft.EntityFrameworkCore;
using SkyFleetRentals.API.Data;
using SkyFleetRentals.API.Models.DTOs;
using SkyFleetRentals.API.Models.Entities;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Services
{
    public class DroneService : IDroneService
    {
        private readonly ApplicationDbContext _context;

        public DroneService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<DroneDto>> GetAllDronesAsync()
        {
            var drones = await _context.Drones
                .Include(d => d.Ratings)
                .Where(d => !d.IsDeleted)
                .ToListAsync();

            return drones.Select(drone => new DroneDto
            {
                Id = drone.Id,
                Model = drone.Model,
                Brand = drone.Brand,
                Status = drone.Status,
                PricePerHour = drone.PricePerHour,
                BatteryLife = drone.BatteryLife,
                Location = drone.Location,
                ImageUrl = drone.ImageUrl,
                GuideUrl = drone.GuideUrl,
                DronePrice = drone.DronePrice,
                AverageRating = drone.Ratings.Any() ? drone.Ratings.Average(r => r.Score) : 0,
                TotalRatings = drone.Ratings.Count
            }).ToList();
        }

        public async Task<DroneDto?> GetDroneByIdAsync(int id)
        {
            var drone = await _context.Drones
                .Include(d => d.Ratings)
                .FirstOrDefaultAsync(d => d.Id == id && !d.IsDeleted);

            if (drone == null) return null;

            return new DroneDto
            {
                Id = drone.Id,
                Model = drone.Model,
                Brand = drone.Brand,
                Status = drone.Status,
                PricePerHour = drone.PricePerHour,
                BatteryLife = drone.BatteryLife,
                Location = drone.Location,
                ImageUrl = drone.ImageUrl,
                GuideUrl = drone.GuideUrl,
                DronePrice = drone.DronePrice,
                AverageRating = drone.Ratings.Any() ? drone.Ratings.Average(r => r.Score) : 0,
                TotalRatings = drone.Ratings.Count
            };
        }

        public async Task<List<DroneDto>> GetAvailableDronesAsync()
        {
            var drones = await _context.Drones
                .Include(d => d.Ratings)
                .Where(d => d.Status == DroneStatus.AVAILABLE && !d.IsDeleted)
                .ToListAsync();

            return drones.Select(drone => new DroneDto
            {
                Id = drone.Id,
                Model = drone.Model,
                Brand = drone.Brand,
                Status = drone.Status,
                PricePerHour = drone.PricePerHour,
                BatteryLife = drone.BatteryLife,
                Location = drone.Location,
                ImageUrl = drone.ImageUrl,
                GuideUrl = drone.GuideUrl,
                DronePrice = drone.DronePrice,
                AverageRating = drone.Ratings.Any() ? drone.Ratings.Average(r => r.Score) : 0,
                TotalRatings = drone.Ratings.Count
            }).ToList();
        }

        public async Task<DroneDto> CreateDroneAsync(CreateDroneRequest request)
        {
            var drone = new Drone
            {
                Model = request.Model,
                Brand = request.Brand,
                Status = DroneStatus.AVAILABLE,
                PricePerHour = request.PricePerHour,
                BatteryLife = request.BatteryLife,
                Location = request.Location,
                ImageUrl = request.ImageUrl,
                GuideUrl = request.GuideUrl,
                DronePrice = request.DronePrice
            };

            _context.Drones.Add(drone);
            await _context.SaveChangesAsync();

            return new DroneDto
            {
                Id = drone.Id,
                Model = drone.Model,
                Brand = drone.Brand,
                Status = drone.Status,
                PricePerHour = drone.PricePerHour,
                BatteryLife = drone.BatteryLife,
                Location = drone.Location,
                ImageUrl = drone.ImageUrl,
                GuideUrl = drone.GuideUrl,
                DronePrice = drone.DronePrice,
                AverageRating = 0,
                TotalRatings = 0
            };
        }

        public async Task<DroneDto?> UpdateDroneAsync(int id, UpdateDroneRequest request)
        {
            var drone = await _context.Drones.FindAsync(id);
            if (drone == null || drone.IsDeleted) return null;

            if (request.Model != null) drone.Model = request.Model;
            if (request.Brand != null) drone.Brand = request.Brand;
            if (request.Status.HasValue) drone.Status = request.Status.Value;
            if (request.PricePerHour.HasValue) drone.PricePerHour = request.PricePerHour.Value;
            if (request.BatteryLife.HasValue) drone.BatteryLife = request.BatteryLife.Value;
            if (request.Location != null) drone.Location = request.Location;
            if (request.ImageUrl != null) drone.ImageUrl = request.ImageUrl;
            if (request.GuideUrl != null) drone.GuideUrl = request.GuideUrl;
            if (request.DronePrice.HasValue) drone.DronePrice = request.DronePrice.Value;

            drone.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return await GetDroneByIdAsync(id);
        }

        public async Task<bool> DeleteDroneAsync(int id)
        {
            var drone = await _context.Drones.FindAsync(id);
            if (drone == null || drone.IsDeleted) return false;

            drone.IsDeleted = true;
            drone.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> IsDroneAvailableAsync(int droneId, DateTime startTime, DateTime endTime)
        {
            var drone = await _context.Drones.FindAsync(droneId);
            if (drone == null || drone.Status != DroneStatus.AVAILABLE) return false;

            // Check for overlapping bookings
            var overlappingBookings = await _context.Bookings
                .Where(b => b.DroneId == droneId && 
                           b.Status != BookingStatus.CANCELLED &&
                           ((b.StartTime <= startTime && b.EndTime > startTime) ||
                            (b.StartTime < endTime && b.EndTime >= endTime) ||
                            (b.StartTime >= startTime && b.EndTime <= endTime)))
                .AnyAsync();

            return !overlappingBookings;
        }
    }
}
