package com.skyfleet.rentals.entity;

public enum Role {
	USER,
	ADMIN
}
