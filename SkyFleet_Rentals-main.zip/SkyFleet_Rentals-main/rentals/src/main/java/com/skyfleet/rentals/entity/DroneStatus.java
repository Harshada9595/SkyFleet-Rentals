package com.skyfleet.rentals.entity;

public enum DroneStatus {
	  AVAILABLE,
      BOOKED,
      MAINTENANCE
}
