package com.skyfleet.rentals.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserLoginDTO {

	String email;
	String password;
}
