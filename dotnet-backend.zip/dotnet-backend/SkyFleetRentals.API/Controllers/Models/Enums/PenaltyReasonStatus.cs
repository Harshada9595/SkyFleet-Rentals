namespace SkyFleetRentals.API.Models.Enums
{
    public enum PenaltyReasonStatus
    {
        LATE_RETURN,
        DAMAGE,
        CANCELLATION
    }
}
