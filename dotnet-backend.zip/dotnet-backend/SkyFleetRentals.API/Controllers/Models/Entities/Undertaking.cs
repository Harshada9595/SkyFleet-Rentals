using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SkyFleetRentals.API.Models.Entities
{
    public class Undertaking : BaseEntity
    {
        [Required]
        public int BookingId { get; set; }

        [Required]
        public bool IsAccepted { get; set; } = false;

        [Required]
        [StringLength(2000)]
        public string Terms { get; set; } = string.Empty;

        public DateTime? AcceptedDateTime { get; set; }

        // Navigation property
        [ForeignKey("BookingId")]
        public virtual Booking Booking { get; set; } = null!;
    }
}
