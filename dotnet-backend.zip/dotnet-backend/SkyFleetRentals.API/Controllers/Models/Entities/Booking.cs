using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using SkyFleetRentals.API.Models.Enums;

namespace SkyFleetRentals.API.Models.Entities
{
    public class Booking : BaseEntity
    {
        [Required]
        public int UserId { get; set; }

        [Required]
        public int DroneId { get; set; }

        public DateTime BookingDateTime { get; set; } = DateTime.UtcNow;

        public DateTime? DeliveryDateTime { get; set; }

        [Required]
        public DateTime StartTime { get; set; }

        [Required]
        public DateTime EndTime { get; set; }

        [Required]
        [Column(TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        [Required]
        public BookingStatus Status { get; set; } = BookingStatus.PENDING;

        public DeliveryStatus DeliveryStatus { get; set; } = DeliveryStatus.PENDING;

        // Navigation properties
        [ForeignKey("UserId")]
        public virtual User User { get; set; } = null!;

        [ForeignKey("DroneId")]
        public virtual Drone Drone { get; set; } = null!;

        public virtual ICollection<Payment> Payments { get; set; } = new List<Payment>();
        public virtual ICollection<Penalty> Penalties { get; set; } = new List<Penalty>();
        public virtual ICollection<Undertaking> Undertakings { get; set; } = new List<Undertaking>();
        public virtual ICollection<Rating> Ratings { get; set; } = new List<Rating>();
    }
}
